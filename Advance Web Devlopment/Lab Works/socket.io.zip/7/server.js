var app = require("express")();
var http = require("http").createServer(app);
var io = require("socket.io")(http);
const PORT = 3000;

app.get('/', function( req, res ) {
	res.sendFile( __dirname + "/public/index.html");
});

http.listen(PORT, function() {
	console.log("Server listening on *:" + PORT);
});

var upvote_count = 0; // notice this.

io.on("connection", function( socket ) {
	// console.log("user has connected..");

	socket.on("disconnect", function() {
		// console.log("user has disconnected..");
	});
	// Notice socket.on upvote-event	
	socket.on("upvote-event", function(upvote_flag) {
		upvote_count += upvote_flag ? 1: -1;
		var msg = upvote_count + (upvote_count == 1 ? " upvote": " upvotes");

		console.log(msg);
		io.emit("update-upvotes", msg);
	});
});
