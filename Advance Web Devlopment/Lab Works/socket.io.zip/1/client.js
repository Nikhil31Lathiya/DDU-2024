const io = require("socket.io-client");

//First Connect to Server on a Specific URL (HOST:PORT)
let socket = io("http://localhost:3000");

//Now Listen for Events (welcome event).
socket.on("welcome", (data) => {
   /*For  listener specify event name and mention the callback to which be called once the event is emitted*/
   
   console.log("Msg. from Server: ", data);
});