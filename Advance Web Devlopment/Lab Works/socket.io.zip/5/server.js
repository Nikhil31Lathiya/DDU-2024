var app = require("express")();
var http = require("http").createServer(app);
var io = require("socket.io")(http);
const PORT = 3000;

app.get('/', function( req, res ) {
	res.sendFile( __dirname + "/public/index.html");
});

http.listen(PORT, function() {
	console.log("Server listening on *:" + PORT);
});

io.on("connection", function( socket ) {
	console.log("a user has connected..");

	// Notice the socket.on()
	socket.on("disconnect", function() {
		console.log("user has disconnected..");
	});
});
