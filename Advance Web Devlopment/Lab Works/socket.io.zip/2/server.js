const express = require("express");
const app = express();
const port = 3000;

const http = require("http").createServer();
const io = require("socket.io")(http);


io.on("connection", (socket) => {
    // socket is a Link to the Client 
    console.log("One more client is Connected...");
      
	socket.emit("welcome", "Server: Welcome");
});

//Listen the HTTP Server 
http.listen(port, () => {
    console.log("Server running on Port: " + port);
});