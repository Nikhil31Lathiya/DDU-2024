package com.example.customized;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnToast;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnToast = findViewById(R.id.btnToast);

        btnToast.setOnClickListener(view -> {
            Toast t = new Toast(this);
            View v = getLayoutInflater().inflate(R.layout.customize_toast, null);
            t.setView(v);
            t.setGravity(Gravity.TOP,0,0);
            t.show();

        });
    }
}