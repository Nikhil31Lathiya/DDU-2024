package com.example.arrayaddapterex;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button fontSize , fontColor;
    TextView txtShow;
    int currentSize = 30;
    int index = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fontSize = findViewById(R.id.bntFontSize);
        fontColor = findViewById(R.id.btnFontColor);
        txtShow = findViewById(R.id.txtDisplay);

        int [] colorArr = {Color.RED , Color.BLUE , Color.MAGENTA};

        fontSize.setOnClickListener(view -> {
            currentSize += 5;
            if(currentSize > 50)
            {
                currentSize = 30;
            }
            txtShow.setTextSize(currentSize);
        });

        fontColor.setOnClickListener(view ->{
            index = (index + 1) % colorArr.length;
            txtShow.setTextColor(colorArr[index]);
        });
    }
}