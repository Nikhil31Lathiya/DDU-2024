package com.example.program2;

import android.content.Context;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.*;

import java.io.*;

public class MainActivity extends AppCompatActivity {

    Button btnSave,btnLoad;
    EditText txtInput;
    TextView txtDisplay;
    String Fname = "myFile.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btnSave = findViewById(R.id.btnSave);
        txtInput = findViewById(R.id.txtInput);
        btnLoad = findViewById(R.id.btnLoad);
        txtDisplay = findViewById(R.id.txtDisplay);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try(FileOutputStream fout = openFileOutput(Fname , Context.MODE_PRIVATE))
                {
                    String tmp = txtInput.getText().toString();
                    fout.write(tmp.getBytes());
                    txtInput.setText("");
                    txtDisplay.setText("Data Saved Successfully");
                }
                catch (IOException e)
                {
                    txtDisplay.setText("Error");
                }
            }
        });

        btnLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try(FileInputStream fin = openFileInput(Fname))
                {
                    int c;
                    StringBuilder fContent = new StringBuilder();

                    while((c = fin.read()) != -1)
                    {
                        fContent.append((char) c);
                    }
                    txtDisplay.setText(fContent.toString());
                } catch (IOException e) {
                    txtDisplay.setText("Error");

                }
            }
        });

    }


}