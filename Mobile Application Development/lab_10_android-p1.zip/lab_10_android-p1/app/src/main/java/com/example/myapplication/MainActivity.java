package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btn;
    EditText eRno , Ename , eSem;
    TextView display;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btnSave);
        eRno = findViewById(R.id.Rno);
        Ename = findViewById(R.id.Name);
        eSem = findViewById(R.id.Sem);
        display = findViewById(R.id.txtDisplay);

        SharedPreferences s = getSharedPreferences("student" , MODE_PRIVATE);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String rollno = eRno.getText().toString();
                String Name = Ename.getText().toString();
                String Sem = eSem.getText().toString();

                SharedPreferences.Editor e = s.edit();

                e.putString("roll_no" , rollno);
                e.putString("Name" , Name);
                e.putString("Sem",  Sem );

                e.apply();
                display.setText("Saved Student Details:\nRoll No: " + rollno + "\nName: " + Name + "\nSemester: " + Sem);


            }
        });
    
    }
}