package com.example.lab9_q1_datanase;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText rollnoEditText, nameEditText, marksEditText;
    private StudentDbHelper dbHelper;
    private SQLiteDatabase db;
    private ArrayList<String> studentList;
    private ListView studentListView;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rollnoEditText = findViewById(R.id.rollno);
        nameEditText = findViewById(R.id.name);
        marksEditText = findViewById(R.id.marks);
        studentListView = findViewById(R.id.student_list_view);

        Button addButton = findViewById(R.id.add_button);
        Button editButton = findViewById(R.id.edit_button);
        Button deleteButton = findViewById(R.id.delete_button);
        Button showButton = findViewById(R.id.show_button);

        dbHelper = new StudentDbHelper(this);
        db = dbHelper.getWritableDatabase();

        studentList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, studentList);
        studentListView.setAdapter(adapter);

        addButton.setOnClickListener(view -> addStudent());
        editButton.setOnClickListener(view -> editStudent());
        deleteButton.setOnClickListener(view -> deleteStudent());
        showButton.setOnClickListener(view -> loadStudentList());
    }

    private void addStudent() {
        String rollno = rollnoEditText.getText().toString();
        String name = nameEditText.getText().toString();
        String marks = marksEditText.getText().toString();

        if (rollno.isEmpty() || name.isEmpty() || marks.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        ContentValues values = new ContentValues();
        values.put(StudentDbHelper.COLUMN_ROLL_NO, rollno);
        values.put(StudentDbHelper.COLUMN_NAME, name);
        values.put(StudentDbHelper.COLUMN_MARKS, marks);

        db.insert(StudentDbHelper.TABLE_NAME, null, values);
        Toast.makeText(this, "Student Added", Toast.LENGTH_SHORT).show();

        rollnoEditText.setText("");
        nameEditText.setText("");
        marksEditText.setText("");
        loadStudentList(); // Refresh the list after adding a student
    }

    private void loadStudentList() {
        studentList.clear();

        String query = "SELECT * FROM " + StudentDbHelper.TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);

        int idIndex = cursor.getColumnIndex(StudentDbHelper.COLUMN_ID);
        int rollnoIndex = cursor.getColumnIndex(StudentDbHelper.COLUMN_ROLL_NO);
        int nameIndex = cursor.getColumnIndex(StudentDbHelper.COLUMN_NAME);
        int marksIndex = cursor.getColumnIndex(StudentDbHelper.COLUMN_MARKS);

        if (idIndex == -1 || rollnoIndex == -1 || nameIndex == -1 || marksIndex == -1) {
            Toast.makeText(this, "Error: Column not found in database.", Toast.LENGTH_SHORT).show();
            cursor.close();
            return;
        }

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(idIndex);
                String rollno = cursor.getString(rollnoIndex);
                String name = cursor.getString(nameIndex);
                String marks = cursor.getString(marksIndex);

                studentList.add("ID: " + id + ", Roll No: " + rollno + ", Name: " + name + ", Marks: " + marks);
            } while (cursor.moveToNext());
        } else {
            studentList.add("No students found.");
        }
        cursor.close();

        // Notify adapter that the data has changed
        adapter.notifyDataSetChanged();
    }

    private void editStudent() {
        String rollno = rollnoEditText.getText().toString();
        String name = nameEditText.getText().toString();
        String marks = marksEditText.getText().toString();

        if (rollno.isEmpty() || name.isEmpty() || marks.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        ContentValues values = new ContentValues();
        values.put(StudentDbHelper.COLUMN_NAME, name);
        values.put(StudentDbHelper.COLUMN_MARKS, marks);

        int rows = db.update(StudentDbHelper.TABLE_NAME, values, StudentDbHelper.COLUMN_ROLL_NO + "=?", new String[]{rollno});
        if (rows > 0) {
            Toast.makeText(this, "Student Updated", Toast.LENGTH_SHORT).show();
            clearFields();
            loadStudentList(); // Refresh the list after editing a student
        } else {
            Toast.makeText(this, "No student found with this roll number", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteStudent() {
        String rollno = rollnoEditText.getText().toString();

        if (rollno.isEmpty()) {
            Toast.makeText(this, "Please enter the roll number of the student to delete", Toast.LENGTH_SHORT).show();
            return;
        }

        int rows = db.delete(StudentDbHelper.TABLE_NAME, StudentDbHelper.COLUMN_ROLL_NO + "=?", new String[]{rollno});
        if (rows > 0) {
            Toast.makeText(this, "Student Deleted", Toast.LENGTH_SHORT).show();
            clearFields();
            loadStudentList(); // Refresh the list after deleting a student
        } else {
            Toast.makeText(this, "No student found with this roll number", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearFields() {
        rollnoEditText.setText("");
        nameEditText.setText("");
        marksEditText.setText("");
    }
}
